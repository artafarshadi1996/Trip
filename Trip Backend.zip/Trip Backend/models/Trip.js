const { v4: uuidv4 } = require('uuid');

// Define the trips array
let trips = [];

class Trip {
  constructor(passengerId, driverId, pickupLocation, dropoffLocation, status) {
    this.id = uuidv4(); // Generate a unique trip ID
    this.passengerId = passengerId;
    this.driverId = driverId;
    this.pickupLocation = pickupLocation;
    this.dropoffLocation = dropoffLocation;
    this.status = status; // requested, accepted, completed
  }
}

// Export the Trip class and trips array
module.exports = {
  Trip,
  trips
};
