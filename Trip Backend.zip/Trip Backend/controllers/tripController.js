const { Trip, trips } = require('../models/Trip');

// WebSocket instance (we’ll pass this in from server.js)
let io;

exports.setSocket = (socketIo) => {
  io = socketIo;
};

// Request a new trip (passenger creates a trip request)
exports.requestTrip = (req, res) => {
  const { passengerId, pickupLocation, dropoffLocation } = req.body;

  const newTrip = new Trip(passengerId, null, pickupLocation, dropoffLocation, 'requested');
  trips.push(newTrip);

  console.log('New trip requested:', newTrip);  // Log the new trip

  res.status(201).json({ msg: 'Trip requested', trip: newTrip });
};

// Driver accepts a trip
exports.acceptTrip = (req, res) => {
  const { tripId, driverId } = req.body;

  console.log('Trips before accepting:', JSON.stringify(trips, null, 2));  // Log trips before accepting

  const trip = trips.find(trip => trip.id === tripId);
  if (!trip) {
    console.log(`Trip with ID ${tripId} not found.`);
    return res.status(404).json({ msg: `Trip with ID ${tripId} not found` });
  }

  if (trip.status !== 'requested') {
    console.log(`Trip with ID ${tripId} is not in requested state.`);
    return res.status(400).json({ msg: `Trip with ID ${tripId} is not in the requested state` });
  }

  trip.driverId = driverId;
  trip.status = 'accepted';

  console.log(`Trip ${tripId} accepted by driver ${driverId}`);  // Log the accepted trip

  // Emit an event to notify the passenger that the trip has been accepted
  io.emit('tripAccepted', { tripId, driverId });

  res.json({ msg: 'Trip accepted', trip });
};

// Complete a trip (driver completes the trip)
exports.completeTrip = (req, res) => {
  const { tripId } = req.body;

  console.log('Trips before completing:', JSON.stringify(trips, null, 2));  // Log trips before completing

  const trip = trips.find(trip => trip.id === tripId);
  if (!trip) {
    console.log(`Trip with ID ${tripId} not found.`);
    return res.status(404).json({ msg: `Trip with ID ${tripId} not found` });
  }

  if (trip.status !== 'accepted') {
    console.log(`Trip with ID ${tripId} cannot be completed because it is not in accepted state.`);
    return res.status(400).json({ msg: `Trip with ID ${tripId} is not in the accepted state` });
  }

  trip.status = 'completed';

  console.log(`Trip ${tripId} completed`);  // Log the completed trip

  // Emit an event to notify the passenger and driver that the trip is completed
  io.emit('tripCompleted', { tripId });

  res.json({ msg: 'Trip completed', trip });
};

// Fetch trips for a specific passenger
exports.getPassengerTrips = (req, res) => {
  const { passengerId } = req.query;  // Retrieve the passengerId from the query parameters

  const passengerTrips = trips.filter(trip => trip.passengerId === passengerId);

  if (passengerTrips.length === 0) {
    return res.status(404).json({ msg: `No trips found for passenger with ID ${passengerId}` });
  }

  res.json({ msg: `Trips for passenger ${passengerId}`, trips: passengerTrips });
};

// Fetch available trips for drivers (trips that are in 'requested' state)
exports.getAvailableTrips = (req, res) => {
  const availableTrips = trips.filter(trip => trip.status === 'requested');

  if (availableTrips.length === 0) {
    return res.status(404).json({ msg: 'No available trips for drivers' });
  }

  res.json({ msg: 'Available trips for drivers', trips: availableTrips });
};
