const fs = require('fs');
const path = require('path');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');

// Path to the users.json file
const usersFilePath = path.join(__dirname, '../public/data/users.json');

// Helper function to read users from the JSON file
const getUsers = () => {
  console.log('Attempting to read users from file...');
  const usersData = fs.readFileSync(usersFilePath, 'utf-8');
  const users = JSON.parse(usersData);
  console.log('Users successfully read from file:', users);
  return users;
};

// Helper function to save users to the JSON file
const saveUsers = (users) => {
  console.log('Saving updated users to file...');
  fs.writeFileSync(usersFilePath, JSON.stringify(users, null, 2), 'utf-8');
  console.log('Users successfully saved to file.');
};

// Sign-up function
exports.signup = async (req, res) => {
  const { name, email, password, role } = req.body;

  try {
    console.log(`Sign-up request received. Name: ${name}, Email: ${email}, Role: ${role}`);

    // Read users from JSON file
    const users = getUsers();

    // Check if user already exists
    let user = users.find(user => user.email === email);
    if (user) {
      console.log(`User already exists: ${email}`);
      return res.status(400).json({ msg: 'User already exists' });
    }

    // Hash the password before saving
    console.log('Hashing password...');
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    // Create and store the new user
    user = { id: users.length + 1, name, email, password: hashedPassword, role };
    users.push(user);
    console.log('New user created:', user);

    // Save updated users back to the JSON file
    saveUsers(users);

    // Generate JWT token
    console.log('Generating JWT token...');
    const payload = { userId: user.id, role: user.role };
    const token = jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: '1h' });

    console.log('Signup successful, returning token.');
    res.status(201).json({ token });
  } catch (err) {
    console.error('Error during signup:', err.message);
    res.status(500).json({ msg: 'Server error' });
  }
};

// Log-in function
exports.login = async (req, res) => {
  const { email, password } = req.body;

  try {
    console.log(`Login request received. Email: ${email}`);

    // Read users from JSON file
    const users = getUsers();

    // Check if user exists
    const user = users.find(user => user.email === email);
    if (!user) {
      console.log(`Login failed: User not found (${email})`);
      return res.status(400).json({ msg: 'Invalid credentials' });
    }

    // Compare passwords
    console.log('Comparing passwords...');
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      console.log('Login failed: Invalid password.');
      return res.status(400).json({ msg: 'Invalid credentials' });
    }

    // Generate JWT token
    console.log('Generating JWT token...');
    const payload = { userId: user.id, role: user.role };
    const token = jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: '1h' });

    console.log('Login successful, returning token.');
    res.json({ token });
  } catch (err) {
    console.error('Error during login:', err.message);
    res.status(500).json({ msg: 'Server error' });
  }
};
