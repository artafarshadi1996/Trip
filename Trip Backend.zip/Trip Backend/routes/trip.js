// routes/trip.js

const express = require('express');
const {
  requestTrip,
  acceptTrip,
  completeTrip,
  getPassengerTrips,
  getAvailableTrips
} = require('../controllers/tripController'); // Import the additional controllers
const router = express.Router();

// Define routes for trip-related actions
router.post('/request', requestTrip);        // Route to request a trip
router.put('/accept', acceptTrip);           // Route to accept a trip
router.put('/complete', completeTrip);       // Route to complete a trip
router.get('/passengerTrips', getPassengerTrips);  // Route to get trips for a passenger
router.get('/availableTrips', getAvailableTrips);  // Route to get available trips for drivers

// Export the router to be used in server.js
module.exports = router;
