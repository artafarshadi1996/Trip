const express = require('express');
const { signup, login } = require('../controllers/authController');
const router = express.Router();

// Sign-up route
router.post('/signup', signup);

// Log-in route
router.post('/login', login);

module.exports = router;
