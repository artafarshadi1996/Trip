const express = require('express');
const dotenv = require('dotenv');
const http = require('http');  // Import http to bind Socket.IO
const { Server } = require('socket.io');  // Import Socket.IO correctly
const authRoutes = require('./routes/auth');
const tripRoutes = require('./routes/trip');
const tripController = require('./controllers/tripController');
const path = require('path');

// Initialize Express
const app = express();

// Load environment variables
dotenv.config();

// Middleware to parse JSON requests
app.use(express.json());

// Basic route
app.get('/', (req, res) => {
  res.send('Ride Sharing API');
});

// Create an HTTP server for Socket.IO
const server = http.createServer(app);

// Initialize Socket.IO with the server
const io = new Server(server, {
  cors: {
    origin: '*',  // Allow all origins for Socket.IO
  }
});

// Pass the io instance to the tripController for WebSocket events
tripController.setSocket(io);

// Listen for WebSocket connections
io.on('connection', (socket) => {
  console.log('New client connected:', socket.id);

  // Listen for driver location updates
  socket.on('driverLocation', (locationData) => {
    const { tripId, location } = locationData;

    // Emit the updated location to the passenger
    io.emit('locationUpdate', { tripId, location });
  });

  // Handle client disconnections
  socket.on('disconnect', () => {
    console.log('Client disconnected:', socket.id);
  });
});

// Register auth routes
app.use('/api/auth', authRoutes);

// Register trip routes
app.use('/api/trip', tripRoutes);

// Serve static files from the public folder
app.use(express.static(path.join(__dirname, 'public')));

// Start the server and listen on a port
const PORT = process.env.PORT || 5000;
server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
